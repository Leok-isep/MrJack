package com.company;

public enum Direction {
    North,
    East,
    South,
    West
}